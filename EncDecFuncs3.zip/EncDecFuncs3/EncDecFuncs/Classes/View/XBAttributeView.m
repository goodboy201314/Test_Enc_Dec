//
//  XBEncDencView.m
//  EncDecFuncs
//
//  Created by xiangbin on 2017/11/25.
//  Copyright © 2017年 xiangbin1207. All rights reserved.
//

#import "XBAttributeView.h"

@interface XBAttributeView()
// uiimageView
// 验证的性质
@property (weak, nonatomic) IBOutlet UIImageView *imgView;


// textField
// 运行的次数
@property (weak, nonatomic) IBOutlet UITextField *timesTextField;

// label
@property (weak, nonatomic) IBOutlet UILabel *encTotalLabel;
@property (weak, nonatomic) IBOutlet UILabel *encTimesLabel;
@property (weak, nonatomic) IBOutlet UILabel *encAvgLabel;


@end

@implementation XBAttributeView

- (IBAction)start:(UIButton *)sender {
    NSInteger times = [self.timesTextField.text integerValue];
    
    // 长度或者加密的次数不可以为0
    if(times ==0) {
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"@u@: 加密次数不可以为空或者0!" delegate:nil cancelButtonTitle:@"知道了" otherButtonTitles:nil];
        [alertView show];
        return ;
    }
    // 将原来的旧数据清零
    self.encTotalLabel.text =  self.encAvgLabel.text = @"0ms";
    self.encTimesLabel.text = @"0";
    
    if(self.startBlock!=nil) {
        self.startBlock(times,self.encTotalLabel,self.encTimesLabel,self.encAvgLabel);
        [self pan:nil];
    }
}

+(instancetype)attributeView
{
    return [[[NSBundle mainBundle] loadNibNamed:NSStringFromClass(self) owner:nil options:nil] firstObject];
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    // 添加手势，随便滑动屏幕的其他位置，键盘退出
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)];
    [self addGestureRecognizer:pan];
}

// 退出键盘
-(void)pan:(UIPanGestureRecognizer *)pan
{
    [self endEditing:YES];
}

- (void)setImage:(UIImage *)image
{
    _image = image;
    self.imgView.image = image;
}
@end
