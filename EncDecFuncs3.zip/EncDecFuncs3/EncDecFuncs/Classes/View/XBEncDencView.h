//
//  XBEncDencView.h
//  EncDecFuncs
//
//  Created by xiangbin on 2017/11/25.
//  Copyright © 2017年 xiangbin1207. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^XBEncDencViewBlock)(NSInteger length, NSInteger times,UILabel *encTotalLabel, UILabel *encTimesLabel, UILabel *encAvgLabel,UILabel *dencTotalLabel, UILabel *dencTimesLabel, UILabel *dencAvgLabel);

@interface XBEncDencView : UIView

/**  startBlock  */
@property (nonatomic,strong) XBEncDencViewBlock startBlock;

+(instancetype)encDencView;

@end
