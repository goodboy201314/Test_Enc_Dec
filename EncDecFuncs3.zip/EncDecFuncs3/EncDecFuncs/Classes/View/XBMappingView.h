//
//  XBMappingView.h
//  EncDecFuncs
//
//  Created by xiangbin on 2017/11/25.
//  Copyright © 2017年 xiangbin1207. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^XBMappingViewBlock)(NSInteger length, NSInteger times,UILabel *encTotalLabel, UILabel *encTimesLabel, UILabel *encAvgLabel);

@interface XBMappingView : UIView

/**  startBlock  */
@property (nonatomic,strong) XBMappingViewBlock startBlock;

+(instancetype)mappingView;

@end
