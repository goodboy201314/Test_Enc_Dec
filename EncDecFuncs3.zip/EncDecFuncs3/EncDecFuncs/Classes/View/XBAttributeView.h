//
//  XBMappingView.h
//  EncDecFuncs
//
//  Created by xiangbin on 2017/11/25.
//  Copyright © 2017年 xiangbin1207. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^XBAttributeViewBlock)(NSInteger times,UILabel *encTotalLabel, UILabel *encTimesLabel, UILabel *encAvgLabel);

@interface XBAttributeView : UIView

/**  startBlock  */
@property (nonatomic,strong) XBAttributeViewBlock startBlock;
/**  性质图片  */
@property (nonatomic,strong) UIImage* image;

+(instancetype)attributeView;

@end
