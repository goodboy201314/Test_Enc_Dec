//
//  XBFuncsController.m
//  EncDecFuncs
//
//  Created by xiangbin on 2017/11/25.
//  Copyright © 2017年 xiangbin1207. All rights reserved.
//

#import "XBFuncsController.h"
#import "XBEncDencView.h"
#import "NSString+AES.h"
#import "XBToolObject.h"
#import "NSString+ThreeDES.h"
#import "RSAEncryptor.h"
#import "XBMappingView.h"
#import "MD5Encryptor.h"
#import "SHAEncryptor.h"
#import "HMACEncryptor.h"
#import "XBAttributeView.h"
#import "gmp-iPhoneOS.h"
#import "pbc.h"
#import "pbc_test.h"

pairing_t pairing;
element_t P,a,Pa,b,Pb,c;
element_t res;

@interface XBFuncsController ()

@end

@implementation XBFuncsController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.tableFooterView = [[UIView alloc] init];
}

#pragma mark - AES
- (IBAction)aes:(UIButton *)sender {
    // 创建加密解密的view，并且给block赋值
    XBEncDencView *encDencView = [XBEncDencView encDencView];
    
    encDencView.startBlock = ^(NSInteger length, NSInteger times,UILabel *encTotalLabel, UILabel *encTimesLabel, UILabel *encAvgLabel,UILabel *dencTotalLabel, UILabel *dencTimesLabel, UILabel *dencAvgLabel) {
        
        // aes128
        double encTotalTime = 0;
        double dencTotalTime = 0;
        double begin = 0;
        double end = 0;

        for (NSInteger i=0; i<times; i++) {
            // 1.随机生成指定长度的字符串
            NSString *plainText = [XBToolObject GenerateStringWithLength:length];
            NSString *key = [XBToolObject GenerateStringWithLength:16];
            
            // 2.加密
            // 获取开始时间
            begin =  [NSDate timeIntervalSinceReferenceDate];
            NSString *cryptText = [plainText aes128_encrypt:key];
            end = [NSDate timeIntervalSinceReferenceDate];
            encTotalTime += end - begin;
            
            // 3.解密
            begin =  [NSDate timeIntervalSinceReferenceDate];
            NSString *newPlainText = [cryptText aes128_decrypt:key];
            end = [NSDate timeIntervalSinceReferenceDate];
            dencTotalTime += end - begin;
        }
        
        // 设置运行的结果
        encTotalTime *= 1000;
        dencTotalTime *= 1000;
        encTimesLabel.text = dencTimesLabel.text = [NSString stringWithFormat:@"%ld",times];
        encTotalLabel.text = [NSString stringWithFormat:@"%.6lfms",encTotalTime];
        encAvgLabel.text = [NSString stringWithFormat:@"%.6lfms",encTotalTime / times];
        dencTotalLabel.text = [NSString stringWithFormat:@"%.6lfms",dencTotalTime];
        dencAvgLabel.text = [NSString stringWithFormat:@"%.6lfms",dencTotalTime / times];
        
    };
    
    // push出控制器
    UIViewController *vc = [[UIViewController alloc] init];
    [vc.view addSubview:encDencView];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - DES
- (IBAction)des:(UIButton *)sender {
    // 创建加密解密的view，并且给block赋值
    XBEncDencView *encDencView = [XBEncDencView encDencView];
    encDencView.startBlock = ^(NSInteger length, NSInteger times,UILabel *encTotalLabel, UILabel *encTimesLabel, UILabel *encAvgLabel,UILabel *dencTotalLabel, UILabel *dencTimesLabel, UILabel *dencAvgLabel) {
        
        // 3des
        double encTotalTime = 0;
        double dencTotalTime = 0;
        double begin = 0;
        double end = 0;
        
        for (NSInteger i=0; i<times; i++) {
            // 1.随机生成指定长度的字符串
            NSString *plainText = [XBToolObject GenerateStringWithLength:length];
            NSString *key = [XBToolObject GenerateStringWithLength:24];
            
            // 2.加密
            // 获取开始时间
            begin =  [NSDate timeIntervalSinceReferenceDate];
            NSString *cryptText = [plainText des3_encrypt:key];
            end = [NSDate timeIntervalSinceReferenceDate];
            encTotalTime += end - begin;
            
            // 3.解密
            begin =  [NSDate timeIntervalSinceReferenceDate];
            NSString *newPlainText = [cryptText des3_decrypt:key];
            end = [NSDate timeIntervalSinceReferenceDate];
            dencTotalTime += end - begin;
        }
        
        // 设置运行的结果
        encTotalTime *= 1000;
        dencTotalTime *= 1000;
        encTimesLabel.text = dencTimesLabel.text = [NSString stringWithFormat:@"%ld",times];
        encTotalLabel.text = [NSString stringWithFormat:@"%.6lfms",encTotalTime];
        encAvgLabel.text = [NSString stringWithFormat:@"%.6lfms",encTotalTime / times];
        dencTotalLabel.text = [NSString stringWithFormat:@"%.6lfms",dencTotalTime];
        dencAvgLabel.text = [NSString stringWithFormat:@"%.6lfms",dencTotalTime / times];
        
    };
    
    // push出控制器
    UIViewController *vc = [[UIViewController alloc] init];
    [vc.view addSubview:encDencView];
    [self.navigationController pushViewController:vc animated:YES];
    
}


#pragma mark - RSA
- (IBAction)rsa:(UIButton *)sender {
    // 创建加密解密的view，并且给block赋值
    XBEncDencView *encDencView = [XBEncDencView encDencView];
    encDencView.startBlock = ^(NSInteger length, NSInteger times,UILabel *encTotalLabel, UILabel *encTimesLabel, UILabel *encAvgLabel,UILabel *dencTotalLabel, UILabel *dencTimesLabel, UILabel *dencAvgLabel) {
        
        // rsa
        double encTotalTime = 0;
        double dencTotalTime = 0;
        double begin = 0;
        double end = 0;
        
        for (NSInteger i=0; i<times; i++) {
            // 1.随机生成指定长度的字符串
            NSString *plainText = [XBToolObject GenerateStringWithLength:length];
            
            // 2.加密
            // 获取开始时间
            begin =  [NSDate timeIntervalSinceReferenceDate];
            NSString *cryptText = [RSAEncryptor encryptString:plainText publicKey:[RSAEncryptor publicKey]];
            end = [NSDate timeIntervalSinceReferenceDate];
            encTotalTime += end - begin;
            
            // 3.解密
            begin =  [NSDate timeIntervalSinceReferenceDate];
            NSString *newPlainText = [RSAEncryptor decryptString:cryptText privateKey:[RSAEncryptor privateKey]];
            end = [NSDate timeIntervalSinceReferenceDate];
            dencTotalTime += end - begin;
        }
        
        // 设置运行的结果
        encTotalTime *= 1000;
        dencTotalTime *= 1000;
        encTimesLabel.text = dencTimesLabel.text = [NSString stringWithFormat:@"%ld",times];
        encTotalLabel.text = [NSString stringWithFormat:@"%.6lfms",encTotalTime];
        encAvgLabel.text = [NSString stringWithFormat:@"%.6lfms",encTotalTime / times];
        dencTotalLabel.text = [NSString stringWithFormat:@"%.6lfms",dencTotalTime];
        dencAvgLabel.text = [NSString stringWithFormat:@"%.6lfms",dencTotalTime / times];
    };
    
    // push出控制器
    UIViewController *vc = [[UIViewController alloc] init];
    [vc.view addSubview:encDencView];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - MD5
- (IBAction)md5:(UIButton *)sender {
    // 创建加密解密的view，并且给block赋值
    XBMappingView *encDencView = [XBMappingView mappingView];
    encDencView.startBlock = ^(NSInteger length, NSInteger times,UILabel *encTotalLabel, UILabel *encTimesLabel, UILabel *encAvgLabel) {
        
        // md5
        double encTotalTime = 0;
        double begin = 0;
        double end = 0;
        
        for (NSInteger i=0; i<times; i++) {
            // 1.随机生成指定长度的字符串
            NSString *plainText = [XBToolObject GenerateStringWithLength:length];
            
            // 2.加密
            // 获取开始时间
            begin =  [NSDate timeIntervalSinceReferenceDate];
            NSString *cryptText = [MD5Encryptor encryptString:plainText];
            end = [NSDate timeIntervalSinceReferenceDate];
            encTotalTime += end - begin;
        }
        
        // 设置运行的结果
        encTotalTime *= 1000;
        encTimesLabel.text  = [NSString stringWithFormat:@"%ld",times];
        encTotalLabel.text = [NSString stringWithFormat:@"%.6lfms",encTotalTime];
        encAvgLabel.text = [NSString stringWithFormat:@"%.6lfms",encTotalTime / times];
    };
    
    // push出控制器
    UIViewController *vc = [[UIViewController alloc] init];
    [vc.view addSubview:encDencView];
    [self.navigationController pushViewController:vc animated:YES];

}

#pragma mark - SHA
- (IBAction)sha:(UIButton *)sender {
    // 创建加密解密的view，并且给block赋值
    XBMappingView *encDencView = [XBMappingView mappingView];
    encDencView.startBlock = ^(NSInteger length, NSInteger times,UILabel *encTotalLabel, UILabel *encTimesLabel, UILabel *encAvgLabel) {
        
        // sha512
        double encTotalTime = 0;
        double begin = 0;
        double end = 0;
        
        for (NSInteger i=0; i<times; i++) {
            // 1.随机生成指定长度的字符串
            NSString *plainText = [XBToolObject GenerateStringWithLength:length];
            
            // 2.加密
            // 获取开始时间
            begin =  [NSDate timeIntervalSinceReferenceDate];
            NSString *cryptText = [SHAEncryptor encryptSHA512WithString:plainText];
            end = [NSDate timeIntervalSinceReferenceDate];
            encTotalTime += end - begin;
        }
        
        // 设置运行的结果
        encTotalTime *= 1000;
        encTimesLabel.text  = [NSString stringWithFormat:@"%ld",times];
        encTotalLabel.text = [NSString stringWithFormat:@"%.6lfms",encTotalTime];
        encAvgLabel.text = [NSString stringWithFormat:@"%.6lfms",encTotalTime / times];
    };
    
    // push出控制器
    UIViewController *vc = [[UIViewController alloc] init];
    [vc.view addSubview:encDencView];
    [self.navigationController pushViewController:vc animated:YES];

}

#pragma mark - HMAC
- (IBAction)hmac:(UIButton *)sender {
    // 创建加密解密的view，并且给block赋值
    XBMappingView *encDencView = [XBMappingView mappingView];
    encDencView.startBlock = ^(NSInteger length, NSInteger times,UILabel *encTotalLabel, UILabel *encTimesLabel, UILabel *encAvgLabel) {
        
        // HmacSHA256
        double encTotalTime = 0;
        double begin = 0;
        double end = 0;
        
        for (NSInteger i=0; i<times; i++) {
            // 1.随机生成指定长度的字符串
            NSString *plainText = [XBToolObject GenerateStringWithLength:length];
            NSString *key = [XBToolObject GenerateStringWithLength:32];
            // 2.加密
            // 获取开始时间
            begin =  [NSDate timeIntervalSinceReferenceDate];
            NSString *cryptText = [HMACEncryptor encryptHMAC:plainText withKey:key];
            end = [NSDate timeIntervalSinceReferenceDate];
            encTotalTime += end - begin;
        }
        
        // 设置运行的结果
        encTotalTime *= 1000;
        encTimesLabel.text  = [NSString stringWithFormat:@"%ld",times];
        encTotalLabel.text = [NSString stringWithFormat:@"%.6lfms",encTotalTime];
        encAvgLabel.text = [NSString stringWithFormat:@"%.6lfms",encTotalTime / times];
    };
    
    // push出控制器
    UIViewController *vc = [[UIViewController alloc] init];
    [vc.view addSubview:encDencView];
    [self.navigationController pushViewController:vc animated:YES];
    
}

#pragma mark - ECC
- (IBAction)ecc:(id)sender {
    // 创建加密解密的view，并且给block赋值
    XBAttributeView *encDencView = [XBAttributeView attributeView];
    
    encDencView.image = [UIImage imageNamed:@"mult"];
    
    encDencView.startBlock = ^(NSInteger times,UILabel *encTotalLabel, UILabel *encTimesLabel, UILabel *encAvgLabel) {
        
        // 点乘
        double encTotalTime = 0;
        double  begin = 0;
        double end = 0;
        
        // 初始化双线性映射相关的参数
        NSString * fullPath = [[NSBundle mainBundle] pathForResource:@"a.param" ofType:nil];
        const char *ss = [fullPath cStringUsingEncoding:NSUTF8StringEncoding];
       
        for (NSInteger i=0; i<times; i++) {
            // 获取开始时间
            begin =  [NSDate timeIntervalSinceReferenceDate];
            
            pbc_demo_pairing_init(pairing,ss);
            if (!pairing_is_symmetric(pairing)) pbc_die("pairing must be symmetric");
            // 将参数P,a,Pa绑定到群上
            element_init_G1(P, pairing);
            element_init_Zr(a, pairing);
            element_init_G1(Pa, pairing);
            // 参数P初始化
            element_from_hash(P, "a.properties", 12);
            element_random(a);
            element_mul_zn(Pa, P, a);
            
            end = [NSDate timeIntervalSinceReferenceDate];
            encTotalTime += end - begin;
        }
       
        
        // 设置运行的结果
        encTotalTime *= 1000;
        encTimesLabel.text  = [NSString stringWithFormat:@"%ld",times];
        encTotalLabel.text = [NSString stringWithFormat:@"%.6lfms",encTotalTime];
        encAvgLabel.text = [NSString stringWithFormat:@"%.6lfms",encTotalTime / times];
    };
    
    // push出控制器
    UIViewController *vc = [[UIViewController alloc] init];
    [vc.view addSubview:encDencView];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - BP
- (IBAction)bp:(id)sender {
    // 创建加密解密的view，并且给block赋值
    XBAttributeView *encDencView = [XBAttributeView attributeView];
    
    encDencView.image = [UIImage imageNamed:@"bp"];
    
    encDencView.startBlock = ^(NSInteger times,UILabel *encTotalLabel, UILabel *encTimesLabel, UILabel *encAvgLabel) {
        
        // bp
        double encTotalTime = 0;
        double  begin = 0;
        double end = 0;
        
        // 初始化双线性映射相关的参数
        NSString * fullPath = [[NSBundle mainBundle] pathForResource:@"a.param" ofType:nil];
        const char *ss = [fullPath cStringUsingEncoding:NSUTF8StringEncoding];
        
        for (NSInteger i=0; i<times; i++) {
            // 获取开始时间
            begin =  [NSDate timeIntervalSinceReferenceDate];
            
            pbc_demo_pairing_init(pairing,ss);
            if (!pairing_is_symmetric(pairing)) pbc_die("pairing must be symmetric");
            // 将参数P, a, Pa, b, Pb, c, res 绑定到群上
            element_init_G1(P, pairing);
            element_init_Zr(a, pairing);
            element_init_Zr(b, pairing);
            element_init_Zr(c, pairing);
            element_init_G1(Pa, pairing);
            element_init_G1(Pb, pairing);
            element_init_GT(res, pairing);
            // 参数P初始化
            element_from_hash(P, "a.properties", 12);
            element_random(a);
            element_random(b);
            element_random(c);
            element_mul_zn(Pa, P, a);
            element_mul_zn(Pb, P, b);
            
            // 计算e(Pa,Pb)^c
            element_pairing(res, Pa, Pb); // 没有^c
            element_pow_zn(res, res, c);
            
            end = [NSDate timeIntervalSinceReferenceDate];
            encTotalTime += end - begin;
        }
        
        
        // 设置运行的结果
        encTotalTime *= 1000;
        encTimesLabel.text  = [NSString stringWithFormat:@"%ld",times];
        encTotalLabel.text = [NSString stringWithFormat:@"%.6lfms",encTotalTime];
        encAvgLabel.text = [NSString stringWithFormat:@"%.6lfms",encTotalTime / times];
    };
    
    // push出控制器
    UIViewController *vc = [[UIViewController alloc] init];
    [vc.view addSubview:encDencView];
    [self.navigationController pushViewController:vc animated:YES];

}



@end
