//
//  XBFuncsController.h
//  EncDecFuncs
//
//  Created by xiangbin on 2017/11/25.
//  Copyright © 2017年 xiangbin1207. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XBFuncsController : UITableViewController

@end
