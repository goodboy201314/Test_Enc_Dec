/*!  头文件方法实现的基本信息。
 @file XBToolObject.m
 @brief 关于这个源文件的简单描述
 @author 项斌
 @version    1.00 2017/11/25 Creation (此文档的版本信息)
   Copyright © 2017年 xiangbin1207. All rights reserved.
 */

#import "XBToolObject.h"

@implementation XBToolObject
/** 获得指定位数的字符串 */
+(NSString *)GenerateStringWithLength:(NSInteger)length
{
    // 生成字符串列表
    NSString *charaString = @"0123456789abcdefghigklmnopqrstuvwxyzABCDEFGHIGKLMNOPQRSTUVWXYZ+-=!#$%^&*";
    NSInteger charaLength = [charaString length];
    
    // 生成指定长度的字符串
    char c = ' ';
    NSInteger rand = 0;
    NSMutableString *string = [NSMutableString string];
    for (NSInteger i=0; i<length; i++) {
        rand = arc4random_uniform((uint32_t)charaLength);
        c = [charaString characterAtIndex:rand];
        [string appendString:[NSString stringWithFormat:@"%c",c]];
    }
    
    return string;
}
@end
