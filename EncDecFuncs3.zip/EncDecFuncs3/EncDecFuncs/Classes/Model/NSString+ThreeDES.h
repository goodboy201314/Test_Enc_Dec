//
//  NSString+ThreeDES.h
//  test_3des
//
//  Created by xiangbin on 2017/11/24.
//  Copyright © 2017年 xiangbin1207. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (ThreeDES)

/**
 *  3des加密
 *
 *  @param key 密钥
 *
 *  @return 加密后的返回值
 */
- (NSString *)des3_encrypt:(NSString *)key;

/**
 *  3des解密
 *
 *  @param key 密钥
 *
 *  @return 解密后的返回值
 */
- (NSString *)des3_decrypt:(NSString *)key;

@end
