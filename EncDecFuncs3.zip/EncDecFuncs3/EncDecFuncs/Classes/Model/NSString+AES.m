//
//  NSString+AES.m
//  NSString的分类，用于实现AES加密解密的实现
//
//  Created by xiangbin on 2017/11/24.
//  Copyright © 2017年 项斌. All rights reserved.
//

#import "NSString+AES.h"
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCryptor.h>

/***
 　kCCKeySizeAES256
 
 　　密钥长度，枚举类型，还有128，192两种。
 
 　　kCCBlockSizeAES128
 
 　　块长度，固定值 16（字节，128位），由AES算法内部加密细节决定，不过哪种方式、模式，均为此。
 
 　　kCCAlgorithmAES
 
 　　算法名称，不区分是128、192还是258。kCCAlgorithmAES128只是历史原因，与kCCAlgorithmAES值相同。
 
 　　kCCOptionPKCS7Padding
 
 　　填充模式，AES算法内部加密细节决定AES的明文必须为64位的整数倍，如果位数不足，则需要补齐。kCCOptionPKCS7Padding表示，缺几位就补几个几。比如缺少3位，则在明文后补3个3。iOS种只有这一种补齐方式，其它平台方式更多，如kCCOptionPKCS5Padding，kCCOptionZeroPadding。如果要实现一致性，则此处其它平台也要使用kCCOptionPKCS7Padding。
 
 　　kCCOptionECBMode
 
 　　工作模式，电子密码本模式。此模式不需要初始化向量。iOS种只有两种方式，默认是CBC模式，即块加密模式。标准的AES除此外还有其它如CTR,CFB等方式。kCCOptionECBMode模式下多平台的要求不高，推荐使用。CBC模式，要求提供相同的初始化向量，多个平台都要保持一致，工作量加大，安全性更高，适合更高要求的场景使用。
 
 */


@implementation NSString (AES)
#pragma mark - AES128
/**
 *  字符串的加密
 *
 *  @param key 密钥
 *
 *  @return 加密后的字符串
 */
-(NSString *)aes128_encrypt:(NSString *)key
{
    const char *cstr = [self cStringUsingEncoding:NSUTF8StringEncoding];
    NSData *data = [NSData dataWithBytes:cstr length:self.length];
    
    //对数据进行加密
    char keyPtr[kCCKeySizeAES128+1];
    bzero(keyPtr, sizeof(keyPtr));
    [key getCString:keyPtr maxLength:sizeof(keyPtr) encoding:NSUTF8StringEncoding];
    NSUInteger dataLength = [data length];
    size_t bufferSize = dataLength + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    size_t numBytesEncrypted = 0;
    CCCryptorStatus cryptStatus = CCCrypt(kCCEncrypt, kCCAlgorithmAES,
                                          kCCOptionPKCS7Padding | kCCOptionECBMode,
                                          keyPtr, kCCKeySizeAES128,
                                          NULL,
                                          [data bytes], dataLength,
                                          buffer, bufferSize,
                                          &numBytesEncrypted);
    if (cryptStatus == kCCSuccess)
    {
        NSData *result = [NSData dataWithBytesNoCopy:buffer length:numBytesEncrypted];
        //base64
        return [result base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
    }else
    {
        return nil;
    }
    
}

/**
 *  字符串的解密
 *
 *  @param key 密钥
 *
 *  @return 解密后的字符串
 */
-(NSString *)aes128_decrypt:(NSString *)key
{
    NSData *data = [[NSData alloc] initWithBase64EncodedData:[self dataUsingEncoding:NSASCIIStringEncoding] options:NSDataBase64DecodingIgnoreUnknownCharacters];
    
    //对数据进行解密
    char keyPtr[kCCKeySizeAES128+1];
    bzero(keyPtr, sizeof(keyPtr));
    [key getCString:keyPtr maxLength:sizeof(keyPtr) encoding:NSUTF8StringEncoding];
    NSUInteger dataLength = [data length];
    size_t bufferSize = dataLength + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    size_t numBytesDecrypted = 0;
    CCCryptorStatus cryptStatus = CCCrypt(kCCDecrypt, kCCAlgorithmAES,
                                          kCCOptionPKCS7Padding | kCCOptionECBMode,
                                          keyPtr, kCCKeySizeAES128,
                                          NULL,
                                          [data bytes], dataLength,
                                          buffer, bufferSize,
                                          &numBytesDecrypted);
    if (cryptStatus == kCCSuccess)
    {
        NSData* result = [NSData dataWithBytesNoCopy:buffer length:numBytesDecrypted];
        
        return [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
        
    }else
    {
        return nil;
    }
    
}




#pragma mark - AES256
/**
 *  字符串的加密
 *
 *  @param key 密钥
 *
 *  @return 加密后的字符串
 */
-(NSString *)aes256_encrypt:(NSString *)key
{
    const char *cstr = [self cStringUsingEncoding:NSUTF8StringEncoding];
    NSData *data = [NSData dataWithBytes:cstr length:self.length];
    
    //对数据进行加密
    char keyPtr[kCCKeySizeAES256+1];
    bzero(keyPtr, sizeof(keyPtr));
    [key getCString:keyPtr maxLength:sizeof(keyPtr) encoding:NSUTF8StringEncoding];
    NSUInteger dataLength = [data length];
    size_t bufferSize = dataLength + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    size_t numBytesEncrypted = 0;
    CCCryptorStatus cryptStatus = CCCrypt(kCCEncrypt, kCCAlgorithmAES,
                                          kCCOptionPKCS7Padding | kCCOptionECBMode,
                                          keyPtr, kCCKeySizeAES256,
                                          NULL,
                                          [data bytes], dataLength,
                                          buffer, bufferSize,
                                          &numBytesEncrypted);
    if (cryptStatus == kCCSuccess)
    {
        NSData *result = [NSData dataWithBytesNoCopy:buffer length:numBytesEncrypted];
        //base64
        return [result base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
    }else
    {
        return nil;
    }
    
}

/**
 *  字符串的解密
 *
 *  @param key 密钥
 *
 *  @return 解密后的字符串
 */
-(NSString *)aes256_decrypt:(NSString *)key
{
    NSData *data = [[NSData alloc] initWithBase64EncodedData:[self dataUsingEncoding:NSASCIIStringEncoding] options:NSDataBase64DecodingIgnoreUnknownCharacters];
    
    //对数据进行解密
    char keyPtr[kCCKeySizeAES256+1];
    bzero(keyPtr, sizeof(keyPtr));
    [key getCString:keyPtr maxLength:sizeof(keyPtr) encoding:NSUTF8StringEncoding];
    NSUInteger dataLength = [data length];
    size_t bufferSize = dataLength + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    size_t numBytesDecrypted = 0;
    CCCryptorStatus cryptStatus = CCCrypt(kCCDecrypt, kCCAlgorithmAES,
                                          kCCOptionPKCS7Padding | kCCOptionECBMode,
                                          keyPtr, kCCKeySizeAES256,
                                          NULL,
                                          [data bytes], dataLength,
                                          buffer, bufferSize,
                                          &numBytesDecrypted);
    if (cryptStatus == kCCSuccess)
    {
        NSData* result = [NSData dataWithBytesNoCopy:buffer length:numBytesDecrypted];
        
        return [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
        
    }else
    {
        return nil;
    }
    
}
@end
