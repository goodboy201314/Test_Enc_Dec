/*!  头文件的基本信息。
 @file XBToolObject.h
 @brief 关于这个源文件的简单描述
 @author 项斌
 @version    1.00 2017/11/25 Creation (此文档的版本信息)
   Copyright © 2017年 xiangbin1207. All rights reserved.
 */

#import <Foundation/Foundation.h>

@interface XBToolObject : NSObject
/**
 *  获得指定位数的字符串
 *
 *  @param length 字符串的位数（以字节为单位）
 *
 *  @return 随机生成的串
 */
+(NSString *)GenerateStringWithLength:(NSInteger)length;

@end
