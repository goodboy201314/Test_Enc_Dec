/*!  头文件方法实现的基本信息。
 @file MD5Encryptor.m
 @brief 关于这个源文件的简单描述
 @author 项斌
 @version    1.00 2017/11/25 Creation (此文档的版本信息)
   Copyright © 2017年 xiangbin1207. All rights reserved.
 */

#import "MD5Encryptor.h"
#import <CommonCrypto/CommonDigest.h>

@implementation MD5Encryptor
+ (NSString *)encryptString:(NSString *)str
{
    
    const char *cStr = [str UTF8String];//转换成utf-8
    
    //开辟一个16字节（128位：md5加密出来就是128位/bit）的空间
    //（一个字节=8字位=8个二进制数）
    
    unsigned char result[16];
    CC_MD5( cStr, (CC_LONG)strlen(cStr), result);
    /*
     extern unsigned char *CC_MD5(const void *data, CC_LONG len, unsigned char *md)官方封装好的加密方法
     把cStr字符串转换成了32位的16进制数列（这个过程不可逆转） 存储到了result这个空间中
     */
    NSMutableString *restltStr = [NSMutableString string];
    for (NSInteger i=0; i<16; i++) {
        [restltStr appendString:[NSString stringWithFormat:@"%02x",result[i]]];
    }
    
    return restltStr;
    
    /*
     x表示十六进制，%02X  意思是不足两位将用0补齐，如果多余两位则不影响
     NSLog("%02X", 0x888);  //888
     NSLog("%02X", 0x4); //04
     */
}
@end
