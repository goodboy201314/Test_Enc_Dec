/*!  头文件的基本信息。
 @file HMACEncryptor.h
 @brief 关于这个源文件的简单描述
 @author 项斌
 @version    1.00 2017/11/25 Creation (此文档的版本信息)
   Copyright © 2017年 xiangbin1207. All rights reserved.
 */

#import <Foundation/Foundation.h>

@interface HMACEncryptor : NSObject
/**
 *  加密方式,MAC算法: HmacSHA256
 *
 *  @param plaintext 要加密的文本
 *  @param key       秘钥，没有长度的要求，但是推荐的最小密钥长度是输出字节  这里是32个字节（因为输出是32个字节）
 *
 *  @return 加密后的字符串
 */
+ (NSString *)encryptHMAC:(NSString *)plaintext withKey:(NSString *)key;
@end
