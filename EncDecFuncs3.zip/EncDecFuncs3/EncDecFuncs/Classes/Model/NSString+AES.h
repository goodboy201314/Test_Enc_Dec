//
//  NSString+AES.h
//  NSString的分类，用于实现AES加密解密的实现
//  这里主要实现的密钥长度是128位的和256位的
//   加密模式：ECB
//   加密填充：kCCOptionPKCS7Padding
//   数据块：128位
//   偏移量：0
//  Created by xiangbin on 2017/11/24.
//  Copyright © 2017年 项斌. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (AES)

/**
 *  字符串的AES加密
 *
 *  @param key 密钥
 *
 *  @return 加密后的字符串
 */
-(NSString *)aes256_encrypt:(NSString *)key;


/**
 *  字符串的解密
 *
 *  @param key 密钥
 *
 *  @return 解密后的字符串
 */
-(NSString *)aes256_decrypt:(NSString *)key;

/**
 *  字符串的AES加密
 *
 *  @param key 密钥
 *
 *  @return 加密后的字符串
 */
-(NSString *)aes128_encrypt:(NSString *)key;


/**
 *  字符串的解密
 *
 *  @param key 密钥
 *
 *  @return 解密后的字符串
 */
-(NSString *)aes128_decrypt:(NSString *)key;

@end
