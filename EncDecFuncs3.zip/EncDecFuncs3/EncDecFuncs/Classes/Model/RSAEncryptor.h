/*!  头文件的基本信息。
 @file RSAEncryptor.h
 @brief 关于这个源文件的简单描述
 @author 项斌
 @version    1.00 2017/11/25 Creation (此文档的版本信息)
   Copyright © 2017年 xiangbin1207. All rights reserved.
 */

#import <Foundation/Foundation.h>

@interface RSAEncryptor : NSObject
#pragma mark - 加密解密的公钥和私钥
// 可以打开这个网站：http://web.chacuo.net/netrsakeypair，自动生成
+(NSString *)publicKey;
+(NSString *)privateKey;

#pragma mark - 公钥私钥加解密
/**
 *  加密方法
 *
 *  @param str    需要加密的字符串
 *  @param pubKey 公钥字符串
 */
+ (NSString *)encryptString:(NSString *)str publicKey:(NSString *)pubKey;

/**
 *  解密方法
 *
 *  @param str     需要解密的字符串
 *  @param privKey 私钥字符串
 */
+ (NSString *)decryptString:(NSString *)str privateKey:(NSString *)privKey;

@end
