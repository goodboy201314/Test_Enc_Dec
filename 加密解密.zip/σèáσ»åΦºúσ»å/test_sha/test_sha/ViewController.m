//
//  ViewController.m
//  test_sha
//
//  Created by xiangbin on 2017/11/25.
//  Copyright © 2017年 xiangbin1207. All rights reserved.
//

#import "ViewController.h"
#import "SHAEncryptor.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    NSString *str = @"xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!xiangbin is a boy!";
//    NSLog(@"sha1:%@",[SHAEncryptor encryptSHA1WithString:str]);
//    NSLog(@"sha224:%@",[SHAEncryptor encryptSHA224WithString:str]);
//    NSLog(@"sha256:%@",[SHAEncryptor encryptSHA256WithString:str]);
//    NSLog(@"sha384:%@",[SHAEncryptor encryptSHA384WithString:str]);
//    NSLog(@"sha512:%@",[SHAEncryptor encryptSHA512WithString:str]);
    double begin =  [NSDate timeIntervalSinceReferenceDate];
    
    for (int i=0; i<10000; i++) {
        [SHAEncryptor encryptSHA256WithString:str];
    }
    
    double end =  [NSDate timeIntervalSinceReferenceDate];
    NSLog(@"%.6f", (end - begin) * 1000 / 10000 );
}


@end
