/*!  头文件的基本信息。
 @file SHAEncryptor.h
 @brief 关于这个源文件的简单描述
 @author 项斌
 @version    1.00 2017/11/25 Creation (此文档的版本信息)
   Copyright © 2017年 xiangbin1207. All rights reserved.
 */

#import <Foundation/Foundation.h>

@interface SHAEncryptor : NSObject
/**
 *  基本的hash
 *
 *  @return 结果：十六进制的字符串显示
 */
+ (NSString *) encryptSHA1WithString:(NSString *)string;


/**
 *  224位的hash
 *
 *  @return 结果：十六进制的字符串显示
 */
+ (NSString *) encryptSHA224WithString:(NSString *)string;


/**
 *  256位hash
 *
 *  @return 结果：十六进制的字符串显示
 */
+ (NSString *) encryptSHA256WithString:(NSString *)string;


/**
 *  384位hash
 *
 *  @return 结果：十六进制的字符串显示
 */
+ (NSString *) encryptSHA384WithString:(NSString *)string;


/**
 *  512位hash
 *
 *  @return 结果：十六进制的字符串显示
 */
+ (NSString *) encryptSHA512WithString:(NSString *)string;
@end
