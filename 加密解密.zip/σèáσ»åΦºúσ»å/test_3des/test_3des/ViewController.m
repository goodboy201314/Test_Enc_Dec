//
//  ViewController.m
//  test_3des
//
//  Created by xiangbin on 2017/11/24.
//  Copyright © 2017年 xiangbin1207. All rights reserved.
//

#import "ViewController.h"
#import "NSString+ThreeDES.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *plainText = @"O57W05XN-EQ2HCD3V-LPJJ4H0N-ZFO2WHRR-9HAVXR2J-YTYXDQPK-SJXZXALI-FAIHJV";
    NSString *key = @"123456789012345678901234";  // 一个char8bit
    
    NSString *cryptText = [plainText des3_encrypt:key];
    NSLog(@"cryptText:\n%@",cryptText);
    
    NSString *newPlainText = [cryptText des3_decrypt:key];
    NSLog(@"plainText:%@",newPlainText);

}


@end
