//
//  NSString+ThreeDES.m
//  test_3des
//
//  Created by xiangbin on 2017/11/24.
//  Copyright © 2017年 xiangbin1207. All rights reserved.
//

#import "NSString+ThreeDES.h"
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCryptor.h>
#import <Security/Security.h>


@implementation NSString (ThreeDES)

/**
 *  3des加密
 *
 *  @param key 密钥
 *
 *  @return 加密后的返回值
 */
- (NSString *)des3_encrypt:(NSString *)key
{
    //把string 转NSData
    NSData* data = [self dataUsingEncoding:NSUTF8StringEncoding];
    
    //length
    size_t plainTextBufferSize = [data length];
    
    const void *vplainText = (const void *)[data bytes];
    
    uint8_t *bufferPtr = NULL;
    size_t bufferPtrSize = 0;
    size_t movedBytes = 0;
    
    bufferPtrSize = (plainTextBufferSize + kCCBlockSize3DES) & ~(kCCBlockSize3DES - 1);
    bufferPtr = malloc( bufferPtrSize * sizeof(uint8_t));
    memset((void *)bufferPtr, 0x0, bufferPtrSize);
    
    const void *vkey = (const void *) [key UTF8String];
    
    //配置CCCrypt
    CCCryptorStatus ccStatus = CCCrypt(kCCEncrypt,
                                       kCCAlgorithm3DES, //3DES
                                       kCCOptionECBMode | kCCOptionPKCS7Padding, //设置模式
                                       vkey,    //key
                                       kCCKeySize3DES,
                                       nil,     //偏移量，这里不用，设置为nil;不用的话，必须为nil,不可以为@“”
                                       vplainText,
                                       plainTextBufferSize,
                                       (void *)bufferPtr,
                                       bufferPtrSize,
                                       &movedBytes);
    
    if (ccStatus == kCCSuccess)
    {
        NSData *result = [NSData dataWithBytes:(const void *)bufferPtr length:(NSUInteger)movedBytes];
        //base64
        return [result base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
    }else
    {
        return nil;
    }

}

/**
 *  3des解密
 *
 *  @param key 密钥
 *
 *  @return 解密后的返回值
 */
- (NSString *)des3_decrypt:(NSString *)key
{
    NSData *encryptData = [[NSData alloc] initWithBase64EncodedData:[self dataUsingEncoding:NSASCIIStringEncoding] options:NSDataBase64DecodingIgnoreUnknownCharacters];

    size_t plainTextBufferSize = [encryptData length];
    const void *vplainText = [encryptData bytes];
    
    uint8_t *bufferPtr = NULL;
    size_t bufferPtrSize = 0;
    size_t movedBytes = 0;
    
    bufferPtrSize = (plainTextBufferSize + kCCBlockSize3DES) & ~(kCCBlockSize3DES - 1);
    bufferPtr = malloc( bufferPtrSize * sizeof(uint8_t));
    memset((void *)bufferPtr, 0x0, bufferPtrSize);
    
    const void *vkey = (const void *) [key UTF8String];
    
    
    CCCryptorStatus ccStatus = CCCrypt(kCCDecrypt,
                       kCCAlgorithm3DES,
                       kCCOptionPKCS7Padding | kCCOptionECBMode,
                       vkey,
                       kCCKeySize3DES,
                       nil,
                       vplainText,
                       plainTextBufferSize,
                       (void *)bufferPtr,
                       bufferPtrSize,
                       &movedBytes);
    
    if (ccStatus == kCCSuccess)
    {
        NSString *result = [[NSString alloc] initWithData:[NSData dataWithBytes:(const void *)bufferPtr length:(NSUInteger)movedBytes] encoding:NSUTF8StringEncoding];
        return result;
    }else
    {
        return nil;
    }
    
}
@end




















