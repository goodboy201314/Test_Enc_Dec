//
//  ViewController.m
//  test_aes
//
//  Created by xiangbin on 2017/11/24.
//  Copyright © 2017年 xiangbin1207. All rights reserved.
//

#import "ViewController.h"
#import "NSString+AES.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *plainText = @"O57W05XN-EQ2HCD3V-LPJJ4H0N-ZFO2WHRR-9HAVXR2J-YTYXDQPK-SJXZXALI-FAIHJVgfsdgsdfgrwet345rfdt324uireotu90fgu34ntgfdug0y39jtgnfdguwer09tu4039thgnvfdogtu09rjgfng3q4u8tfgongquer980gjtdfgnioqerjgt!#$%^&*-=+";
    NSString *key = @"1234567890123456";  // 一个char8bit
    
    NSString *cryptText = [plainText aes128_encrypt:key];
    NSLog(@"cryptText:\n%@",cryptText);
    
    NSString *newPlainText = [cryptText aes128_decrypt:key];
    NSLog(@"plainText:%@",newPlainText);
    
    
}





@end
