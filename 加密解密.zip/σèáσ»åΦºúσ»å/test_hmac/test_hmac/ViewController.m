//
//  ViewController.m
//  test_hmac
//
//  Created by xiangbin on 2017/11/25.
//  Copyright © 2017年 xiangbin1207. All rights reserved.
//

#import "ViewController.h"
#import "HMACEncryptor.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    NSString *str = @"xiangbin is a good boy";
    NSString *key = @"123";
    
    
    NSLog(@"%@",[HMACEncryptor encryptHMAC:str withKey:key]);
    
}


@end
