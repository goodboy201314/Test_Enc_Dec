//
//  ViewController.m
//  test_rsa
//
//  Created by xiangbin on 2017/11/25.
//  Copyright © 2017年 xiangbin1207. All rights reserved.
//

#import "ViewController.h"
#import "RSAEncryptor.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   NSString *originalString = @"xiangbin is a good boy! He likes eating apple!";
    
    // 加密
    NSString *encryptStr = [RSAEncryptor encryptString:originalString publicKey:[RSAEncryptor publicKey]];
    NSLog(@"加密后：%@",encryptStr);
    
    // 解密
    NSLog(@"解密后：%@",[RSAEncryptor decryptString:encryptStr privateKey:[RSAEncryptor privateKey]]);
    
}


@end
