/*!  头文件的基本信息。
 @file MD5Encryptor.h
 @brief 关于这个源文件的简单描述
 @author 项斌
 @version    1.00 2017/11/25 Creation (此文档的版本信息)
   Copyright © 2017年 xiangbin1207. All rights reserved.
 */

#import <Foundation/Foundation.h>

@interface MD5Encryptor : NSObject
/**
 *  用MD5加密，并且返回加密后的十六进制的字符串形式,返回的是大写的形式哦
 *
 *  @param str 加密字符串
 *
 *  @return 加密后的十六进制的字符串形式
 */
+ (NSString *)encryptString:(NSString *)str;

@end
