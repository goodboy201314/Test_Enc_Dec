//
//  ViewController.m
//  test_md5
//
//  Created by xiangbin on 2017/11/25.
//  Copyright © 2017年 xiangbin1207. All rights reserved.
//

#import "ViewController.h"
#import "MD5Encryptor.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *str = @"xiangbin is a good boy";
    NSLog(@"%@",[MD5Encryptor encryptString:str]);
}


@end
