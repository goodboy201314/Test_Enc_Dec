//
//  ViewController.m
//  test_ecc
//
//  Created by xiangbin on 2017/11/25.
//  Copyright © 2017年 xiangbin1207. All rights reserved.
//

#import "ViewController.h"
#import "gmp-iPhoneOS.h"
#import "pbc.h"
#import "pbc_test.h"

mpz_t a,b,p,res,tt;

@interface ViewController ()

@end

@implementation ViewController

- (void)testDH{
    gmp_randstate_t grt;
    gmp_randinit_default(grt); //设置随机数生成算法为默认
    gmp_randseed_ui(grt, time(NULL));	//设置随机化种子为当前时间，这几条语句的作用相当于标准C中的srand(time(NULL));
    
    mpz_t p;
    mpz_init(p);//一个mpz_t类型的变量必须在初始化后才能被使用
    

    mpz_urandomb(p, grt, 1024);	//随机生成一个在0~2^1024-1之间的随机数
    
    if(mpz_even_p(p))
        mpz_add_ui(p, p, 1); //如果生成的随机数为偶数，则加一
    
    while(!mpz_probab_prime_p(p, 25) > 0)  //逐个检查比p大的奇数是否为素数
        mpz_add_ui(p, p, 2);

// ========= 到此为止  p为1024bit的素数 ================== //
    mpz_t g;
    mpz_init_set_ui(g, 5);  //a = 1
    double  begin =  [NSDate timeIntervalSinceReferenceDate];
    for (int i = 0; i<10000; i++) {
        mpz_set_str(a,[[self GenerateStringWithLength:128] UTF8String],2);
        mpz_powm(res,g,a,p);
    }
    double  end =  [NSDate timeIntervalSinceReferenceDate];
    NSLog(@"%lf",(end - begin) * 1000 / 10000);

}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self testDH];
    return;
    
    
    // ===================== 以前写的代码 =============== //
    // 512个字节
    mpz_set_str(a,[[self GenerateStringWithLength:1024] UTF8String],2);
    mpz_set_str(b,[[self GenerateStringWithLength:1024] UTF8String],2);
    mpz_set_str(p,[[self GenerateStringWithLength:1024] UTF8String],2);

    
    // 计算 a^b mod p
    double  begin =  [NSDate timeIntervalSinceReferenceDate];
    mpz_powm(res,a,b,p);
    double  end =  [NSDate timeIntervalSinceReferenceDate];
    
    NSLog(@"%lf",(end - begin) * 1000);

}


// 生成1024bit的大素数
- (void)test {

    gmp_randstate_t grt;
    gmp_randinit_default(grt); //设置随机数生成算法为默认
    gmp_randseed_ui(grt, time(NULL));	//设置随机化种子为当前时间，这几条语句的作用相当于标准C中的srand(time(NULL));
    
    mpz_t key_p, key_q;
    mpz_init(key_p);
    mpz_init(key_q);	//一个mpz_t类型的变量必须在初始化后才能被使用
    
    mpz_urandomb(key_p, grt, 1024);
    mpz_urandomb(key_q, grt, 1024);	//随机生成一个在0~2^1024-1之间的随机数
    
    if(mpz_even_p(key_p))
        mpz_add_ui(key_p, key_p, 1);
    if(mpz_even_p(key_q))
        mpz_add_ui(key_q, key_q, 1);	//如果生成的随机数为偶数，则加一
    
    while(!mpz_probab_prime_p(key_p, 25) > 0)  //逐个检查比p大的奇数是否为素数
        mpz_add_ui(key_p, key_p, 2);
    while(!mpz_probab_prime_p(key_q, 25) > 0)
        mpz_add_ui(key_q, key_q, 2);
    
    gmp_printf("%ZX\n", key_p);   //以十六进制的形式输出生成的素数
    gmp_printf("%ZX\n", key_q);

}


- (NSString *)GenerateStringWithLength:(NSInteger)length
{
    // 生成字符串列表
    NSString *charaString = @"01";
    NSInteger charaLength = [charaString length];
    
    // 生成指定长度的字符串
    char c = ' ';
    NSInteger rand = 0;
    NSMutableString *string = [NSMutableString string];
    [string appendString:@"1"];
    for (NSInteger i=1; i<length; i++) {
        rand = arc4random_uniform((uint32_t)charaLength);
        c = [charaString characterAtIndex:rand];
        [string appendString:[NSString stringWithFormat:@"%c",c]];
    }
    
    return string;
}


@end
